<?php $__env->startSection("content"); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-xl-8">
                <div class="post mb-4">
                        <div class="row">
                            <h4 class="fw-bold mb-4"><?php echo e($post->title); ?></h4>
                            <img src="<?php echo e(asset("storage/cover/".$post->cover)); ?>" class="cover-img rounded-3 w-100 mb-4" alt="">
                            <p class="text-black-50 mb-4 post-detail">
                                <?php echo e($post->description); ?>

                            </p>

                            <?php if($post->galleries->count()): ?>
                                <div class="gallery border rounded">
                                    <h4 class="text-center fw-bold mt-4">Post Gallery</h4>
                                   <div class="row g-4 py-4 px-2 justify-content-center">
                                       <?php $__currentLoopData = $post->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <div class="col-6 col-lg-4 col-xl-3">
                                               <a class="venobox" data-gall="gallery" href="<?php echo e(asset('storage/gallery/'.$gallery->photo)); ?>">
                                                   <img src="<?php echo e(asset('storage/gallery/'.$gallery->photo)); ?>" class="gallery-photo">
                                               </a>
                                           </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </div>
                                </div>
                            <?php endif; ?>

                        <div class="mb-5">
                            <h4 class="text-center fw-bold">Users Comments</h4>
                            <div class="row justify-content-center">
                                <div class="col-lg-8">

                                    <div class="comments">
                                        <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="border rounded p-4 mb-3">
                                            <div class="d-flex justify-content-between mb-3">
                                                <div class="d-flex">
                                                    <img src="<?php echo e(asset($comment->user->photo)); ?>" class="user-img rounded-circle" alt="">
                                                    <p class="mb-0 ms-2 small">
                                                        <?php echo e($comment->user->name); ?>

                                                        <br>
                                                        <i class="fas fa-calendar"></i>
                                                        <?php echo e($comment->created_at->diffforhumans()); ?>

                                                    </p>
                                                </div>


                                                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$comment)): ?>
                                                <form action="<?php echo e(route('comment.destroy',$comment->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button class="btn btn-outline-danger rounded-circle btn-sm ">
                                                        <i class="fas fa-trash-alt text-danger"></i>
                                                    </button>
                                                </form>
                                                <?php endif; ?>
                                            </div>


                                            <p class="mb-0">
                                                <?php echo e($comment->message); ?>

                                            </p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <p class="text-center">
                                                There is no comment yet !
                                                <?php if(auth()->guard()->check()): ?>
                                                    Start Comment Now
                                                <?php endif; ?>

                                                <?php if(auth()->guard()->guest()): ?>
                                                    <a href="<?php echo e(route('login')); ?>">Login</a> to comment
                                                <?php endif; ?>

                                            </p>
                                        <?php endif; ?>
                                    </div>

                                    <?php if(auth()->guard()->check()): ?>
                                    <form action="<?php echo e(route('comment.store')); ?>" method="post" id="comment-create">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                        <div class="form-floating mb-3">
                                            <textarea class="form-control <?php $__errorArgs = ["message"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="message" placeholder="Leave a comment here" style="height: 150px" id="floatingTextarea"></textarea>
                                            <label for="floatingTextarea">Comments</label>
                                            <?php $__errorArgs = ["message"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback ps-2"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="text-center">
                                            <button class="btn btn-primary">Comment</button>
                                        </div>
                                    </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center border rounded p-4">
                                <div class="d-flex">
                                    <img src="<?php echo e(asset($post->user->photo)); ?>" class="user-img rounded-circle" alt="">
                                    <p class="mb-0 ms-2 small">
                                        <?php echo e($post->user->name); ?>

                                        <br>
                                        <i class="fas fa-calendar"></i>
                                        <?php echo e($post->created_at->format("d M Y")); ?>

                                    </p>
                                </div>

                                <div>
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$post)): ?>
                                        <form action="<?php echo e(route('post.destroy',$post->id)); ?>" method="post" class="d-inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-outline-danger">
                                                <i class="fas fa-trash-alt fa-fw"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("update",$post)): ?>
                                        <a href="<?php echo e(route("post.edit",$post->id)); ?>" class="btn btn-outline-warning">
                                            <i class="fas fa-edit fa-fw"></i>
                                        </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <a href="<?php echo e(route("index")); ?>" class="btn btn-outline-primary">Read All</a>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL LATITUDE\Desktop\the-explorer-laravel\resources\views/post/detail.blade.php ENDPATH**/ ?>