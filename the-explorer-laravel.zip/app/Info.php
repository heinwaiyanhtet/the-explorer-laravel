<?php

namespace App;

class Info
{

}
